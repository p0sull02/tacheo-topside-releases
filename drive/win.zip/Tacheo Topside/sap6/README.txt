SAP6 - PHIL UNDERWOOD'S FIRMWARE, FOR "RESTORE PHIL'S FIRMWARE"
==============================================================
SAP6_CircuitPython_9.0.0_restore.zip is the update package Tacheo installs when you
choose "Restore Phil's firmware" on its SAP6 page. Don't install it any other way: Tacheo first
has the Tacheo clear its own files (CircuitPython keeps its settings in the same internal flash).

What it is
  The application part (0x27000-0xEA000) of Phil Underwood's CircuitPython 9.0.0 build for the
  SAP6, taken unchanged from his installer: github.com/furbrain/STIC, firmware/installer/
  sap6_cp_9.0.0.uf2 (commit 597460d, 24 May 2026). That is the version his installer puts on a
  SAP6 today. The SoftDevice and bootloader on the unit are not touched. Packed with
  adafruit-nrfutil (dfu genpkg, any SoftDevice).
  Phil's own program (the "firmware" folder, code.py, boot.py, his settings in config.json and
  his calibration) lives on the SAP6's drive, which Tacheo never touches, so it comes back as
  it was. Tacheo also keeps a copy of the drive in "SAP6 backups\" from before the conversion.
  Checked 8 Oct 2026: the Phil 1.6.0 files on Sully's SAP6 are identical to that repository
  version, which supports CircuitPython 9.

Licences
  CircuitPython: MIT licence (github.com/adafruit/circuitpython). Phil Underwood's SAP6
  firmware: GNU GPL v3 (github.com/furbrain/STIC, where its source is).
