@echo off
title Survey device updater
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\updater.ps1"
echo.
pause
