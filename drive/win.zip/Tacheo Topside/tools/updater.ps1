# Survey device updater (USB)
# ---------------------------------------------------------------------------
# Does what Phil Underwood's PonyTrainer did for the SAP5: plug the unit in,
# run this, and it installs the newest firmware from the "firmware" folder.
#
#   1. Finds the unit on USB (Seeed XIAO nRF52840 Sense: VID 2886, PID 8045 when
#      running, 0045 when it is in its bootloader).
#   2. Asks it for its version (sends "?"; firmware 0.4+ answers "ID name ver build").
#   3. Shows old and new versions and asks before doing anything.
#   4. Puts it in its bootloader (the standard "1200 baud touch"), waits for the
#      bootloader's port, and sends the firmware with adafruit-nrfutil.
#   5. Waits for it to restart and reads the version again.
#
# A unit that is already sitting in its bootloader (for example after a Bluetooth
# update that failed part way) is flashed directly - that is the recovery path.
# Settings and calibration are kept: the bootloader doesn't touch those pages.
#
# Firmware 1.10 comes in two builds: "breadboard" (the Tacheo) and "sap6" (Phil Underwood's
# SAP6 running Tacheo); 1.14.1 adds "cave" (the Tacheo's own cave units, v1.5 / v2 - the breadboard
# build leaves their screen and compass dark). A unit only ever gets the build it already reports;
# one waiting in its bootloader, or one that doesn't answer, can't say, so the updater asks. A SAP6 still on Phil's firmware (CircuitPython:
# the same USB IDs as the bootloader, plus a drive called SAP6) is not touched here - Tacheo
# Topside's SAP6 page converts it, backing its drive up first.
#
# Runs on the PowerShell that comes with Windows 10/11 (5.1). No install needed.
# Start it with "Update firmware only.cmd" one folder up, or menu 4 in Tacheo Topside.

$ErrorActionPreference = 'Stop'
$VID      = '2886'
$PID_APP  = '8045'
$PID_BOOT = '0045'

$ToolsDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$RootDir  = Split-Path -Parent $ToolsDir
$FwDir    = Join-Path $RootDir 'firmware'
$NrfUtil  = Join-Path $ToolsDir 'adafruit-nrfutil.exe'
$LogFile  = Join-Path $RootDir 'last update log.txt'

function Say([string]$t, [string]$colour = 'Gray') { Write-Host $t -ForegroundColor $colour; Add-Content -Path $LogFile -Value $t -ErrorAction SilentlyContinue }
function Step([string]$t) { Say ''; Say "== $t" 'Cyan' }
function Problem([string]$t) { Say ''; Say "PROBLEM: $t" 'Red' }

# "Tacheo_v0.5_breadboard.zip" -> [version]0.5 ; anything without _v<digits> -> $null
function Get-FwVersionFromName([string]$name) {
    $m = [regex]::Match($name, '_v(\d+(?:\.\d+){0,3})(?:_|\.zip$)', 'IgnoreCase')
    if (-not $m.Success) { return $null }
    $v = $m.Groups[1].Value
    if ($v -notmatch '\.') { $v = "$v.0" }
    return [version]$v
}

# "Tacheo_v1.10_sap6.zip" -> "sap6"
function Get-FwBuildFromName([string]$name) {
    $m = [regex]::Match($name, '_v\d+(?:\.\d+){0,3}_(.+)\.zip$', 'IgnoreCase')
    if ($m.Success) { return $m.Groups[1].Value }
    return ''
}

# Newest firmware .zip in a folder (by the version in its name), or $null. With $build, only that build.
function Get-NewestFirmware([string]$dir, [string]$build = '') {
    if (-not (Test-Path $dir)) { return $null }
    $best = $null; $bestV = $null
    foreach ($f in Get-ChildItem -Path $dir -Filter '*.zip' -File) {
        $v = Get-FwVersionFromName $f.Name
        if ($null -eq $v) { continue }
        if ($build -ne '' -and (Get-FwBuildFromName $f.Name) -ne $build) { continue }
        if ($null -eq $bestV -or $v -gt $bestV) { $best = $f; $bestV = $v }
    }
    if ($null -eq $best) { return $null }
    return [pscustomobject]@{ File = $best; Version = $bestV }
}

# Parses the unit's answer to "?": "ID Tacheo 0.5 breadboard" -> object, else $null
function Read-IdLine([string]$line) {
    $m = [regex]::Match($line, '^ID\s+(\S+)\s+(\S+)\s+(\S+)')
    if (-not $m.Success) { return $null }
    $v = $null
    try { $s = $m.Groups[2].Value; if ($s -notmatch '\.') { $s = "$s.0" }; $v = [version]$s } catch { $v = $null }
    return [pscustomobject]@{ Name = $m.Groups[1].Value; VersionText = $m.Groups[2].Value; Version = $v; Build = $m.Groups[3].Value }
}

# A SAP6 on Phil Underwood's firmware: a removable drive called SAP6 or CIRCUITPY whose
# boot_out.txt names the SAP6 board. Returns the drive letter ("D:") or $null.
function Find-Sap6Drive {
    $disks = Get-CimInstance -ClassName Win32_LogicalDisk -Filter 'DriveType=2' -ErrorAction SilentlyContinue
    foreach ($d in $disks) {
        $label = ([string]$d.VolumeName).ToUpper()
        if ($label -ne 'SAP6' -and $label -ne 'CIRCUITPY') { continue }
        $boot = Join-Path ($d.DeviceID + '\') 'boot_out.txt'
        try { if ((Get-Content -Path $boot -Raw -ErrorAction Stop) -match '\bSAP6\b') { return $d.DeviceID } } catch { }
    }
    return $null
}

# Every unit on USB: Port (COMx) and Mode ('running', 'bootloader', or 'circuitpython' = a SAP6 on
# Phil's firmware, which uses the bootloader's USB IDs).
function Get-UnitPorts {
    $found = @()
    $devs = Get-CimInstance -ClassName Win32_PnPEntity -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -match '\(COM\d+\)' }
    foreach ($d in $devs) {
        $id = [string]$d.PNPDeviceID
        $m = [regex]::Match($id, "VID_$VID&PID_($PID_APP|$PID_BOOT)", 'IgnoreCase')
        if (-not $m.Success) { continue }
        $mode = 'running'
        if ($m.Groups[1].Value -eq $PID_BOOT) { $mode = 'bootloader' }
        $p = [regex]::Match([string]$d.Name, '\((COM\d+)\)')
        $found += [pscustomobject]@{ Port = $p.Groups[1].Value; Mode = $mode }
    }
    $boots = @($found | Where-Object { $_.Mode -eq 'bootloader' })
    if ($boots.Count -gt 0 -and $null -ne (Find-Sap6Drive)) { $boots[0].Mode = 'circuitpython' }
    return $found
}

# Waits up to $seconds for a unit in the given mode; returns its port or $null.
# $not: ports that don't count (e.g. another unit already in its bootloader).
function Wait-ForMode([string]$mode, [int]$seconds, [string[]]$not = @()) {
    $until = (Get-Date).AddSeconds($seconds)
    while ((Get-Date) -lt $until) {
        $u = @(Get-UnitPorts | Where-Object { $_.Mode -eq $mode -and $not -notcontains $_.Port })
        if ($u.Count -gt 0) { return $u[0].Port }
        Start-Sleep -Milliseconds 400
    }
    return $null
}

# Sends "?" and returns the parsed ID line, or $null (older firmware, or busy).
function Get-UnitId([string]$port) {
    $sp = $null
    try {
        $sp = New-Object System.IO.Ports.SerialPort $port, 115200
        $sp.DtrEnable = $true
        $sp.RtsEnable = $true
        $sp.ReadTimeout = 250
        $sp.WriteTimeout = 2000   # 1.6.52: a unit whose firmware froze stops reading its port; without a limit the write waits for ever
        $sp.NewLine = "`n"
        $sp.Open()
        Start-Sleep -Milliseconds 300
        $sp.DiscardInBuffer()
        for ($try = 0; $try -lt 3; $try++) {
            $sp.Write('?')
            $until = (Get-Date).AddSeconds(1.5)
            while ((Get-Date) -lt $until) {
                try {
                    $id = Read-IdLine ($sp.ReadLine().Trim())
                    if ($null -ne $id) { return $id }
                } catch [System.TimeoutException] { }
            }
        }
        return $null
    } catch {
        return $null
    } finally {
        if ($null -ne $sp -and $sp.IsOpen) { $sp.Close() }
    }
}

# v0.6: sends "NAME=<name>" (owner's name for the start-up greeting). True if the unit said OK.
function Set-OwnerName([string]$port, [string]$name) {
    $sp = $null
    try {
        $sp = New-Object System.IO.Ports.SerialPort $port, 115200
        $sp.DtrEnable = $true
        $sp.RtsEnable = $true
        $sp.ReadTimeout = 250
        $sp.WriteTimeout = 2000   # 1.6.52: a unit whose firmware froze stops reading its port; without a limit the write waits for ever
        $sp.NewLine = "`n"
        $sp.Open()
        Start-Sleep -Milliseconds 300
        $sp.DiscardInBuffer()
        $sp.Write("NAME=" + $name + "`n")
        $until = (Get-Date).AddSeconds(2)
        while ((Get-Date) -lt $until) {
            try { if ($sp.ReadLine().Trim() -like 'OK NAME*') { return $true } } catch [System.TimeoutException] { }
        }
        return $false
    } catch {
        return $false
    } finally {
        if ($null -ne $sp -and $sp.IsOpen) { $sp.Close() }
    }
}

# The standard way into the bootloader: open at 1200 baud with DTR on, then close.
function Send-Touch1200([string]$port) {
    $sp = New-Object System.IO.Ports.SerialPort $port, 1200
    $sp.DtrEnable = $true
    try { $sp.Open(); Start-Sleep -Milliseconds 150; $sp.DtrEnable = $false; Start-Sleep -Milliseconds 50 }
    finally { if ($sp.IsOpen) { $sp.Close() } }
}

# 11 Oct 2026 (Topside 1.6.13): which unit is it? '' = not sure / none of these (change nothing).
# 19 Oct 2026 (Topside 1.6.34): 4 = a SAP5 with a XIAO wired on (the sap5x build), offered only where this Topside carries it.
# 20 Oct 2026 (Topside 1.6.35): 5 = the same with the 2" colour screen (the sap5xc build), likewise.
# 27 Oct 2026 (Topside 1.6.42): 6 = a Tacheo 1 with the 2" colour screen and one button (the cavec build), likewise.
function Ask-Board {
    $s5x = $null -ne (Get-NewestFirmware $FwDir 'sap5x')
    $s5xc = $null -ne (Get-NewestFirmware $FwDir 'sap5xc')
    $cvc = $null -ne (Get-NewestFirmware $FwDir 'cavec')
    Say 'Which unit is it?'
    Say '  1 = a SAP6 (Phil Underwood''s Shetland Attack Pony 6, converted to Tacheo)'
    Say '  2 = a cave unit (the Tacheo in its case, v1.5 or v2, black-and-white screen)'
    Say '  3 = the breadboard Tacheo (the bench prototype)'
    if ($s5x) { Say '  4 = a SAP5 with a XIAO wired on (Phil''s SAP5 board, sap5x build)' }
    if ($s5xc) { Say '  5 = a SAP5 with a XIAO and the colour screen (sap5xc build; the plain one leaves that screen dark)' }
    if ($cvc) { Say '  6 = a Tacheo 1 with the colour screen and one button (cavec build; the plain cave build leaves that screen dark)' }
    $n = @('1', '2', '3')
    if ($s5x) { $n += '4' }
    if ($s5xc) { $n += '5' }
    if ($cvc) { $n += '6' }
    $q = 'Type ' + (($n[0..($n.Count - 2)]) -join ', ') + ' or ' + $n[$n.Count - 1]
    $a = (Read-Host ($q + ' (Enter = not sure: change nothing)')).Trim()
    Add-Content -Path $LogFile -Value ("Answer: " + $a) -ErrorAction SilentlyContinue
    if ($a -eq '1') { return 'sap6' }
    if ($a -eq '2') { return 'cave' }
    if ($a -eq '3') { return 'breadboard' }
    if ($a -eq '4' -and $s5x) { return 'sap5x' }
    if ($a -eq '5' -and $s5xc) { return 'sap5xc' }
    if ($a -eq '6' -and $cvc) { return 'cavec' }
    return ''
}

# No package for the build: what to say (the cave build may not be in this Topside yet).
function Problem-NoFirmware([string]$build) {
    if ($build -eq 'cave') {
        Problem "This Topside has no firmware for the cave build yet. Nothing was changed."
        Say 'Install the cave build from its .uf2 file: two quick taps on the unit''s reset button open its'
        Say 'update drive; copy the file onto it.'
    } else { Problem "No firmware for the '$build' build in the 'firmware' folder. Copy the whole Tacheo Topside folder again." }
}

function Ask-YesNo([string]$q, [bool]$default) {
    $hint = '[y/N]'
    if ($default) { $hint = '[Y/n]' }
    $a = Read-Host "$q $hint"
    if ([string]::IsNullOrWhiteSpace($a)) { return $default }
    return $a.Trim().ToLower().StartsWith('y')
}

# 1.6.52: Tacheo Topside, if it is running
function Get-Topside { @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -eq 'Tacheo Topside' }) }

function Main {
    Set-Content -Path $LogFile -Value ("Survey device updater, " + (Get-Date -Format 'yyyy-MM-dd HH:mm')) -ErrorAction SilentlyContinue
    Say 'TACHEO FIRMWARE UPDATER' 'White'
    Say 'Leave the unit plugged in until this says DONE.'

    # Files downloaded in a zip get "blocked" by Windows; unblock our own tools.
    Get-ChildItem -Path $ToolsDir -File | ForEach-Object { try { Unblock-File -Path $_.FullName } catch { } }

    if (-not (Test-Path $NrfUtil)) { Problem "tools\adafruit-nrfutil.exe is missing. Copy the whole updater folder again."; return 1 }
    if ($null -eq (Get-NewestFirmware $FwDir)) { Problem "No firmware .zip in the 'firmware' folder."; return 1 }

    # 1.6.52 (Paul's old SAP6, 2 Nov 2026): Tacheo Topside keeps the unit's port open, and a Topside stuck on a frozen unit can't be
    # ended until the unit is unplugged. Close it first.
    if (@(Get-Topside).Count -gt 0) {
        Step 'Closing Tacheo Topside (it holds the unit''s port)'
        Get-Topside | Stop-Process -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 3
        if (@(Get-Topside).Count -gt 0) {
            Say 'Tacheo Topside is stuck on the unit and will not close. UNPLUG THE UNIT NOW.' 'Yellow'
            $until = (Get-Date).AddSeconds(90)
            while (@(Get-Topside).Count -gt 0 -and (Get-Date) -lt $until) { Start-Sleep -Seconds 1; Get-Topside | Stop-Process -Force -ErrorAction SilentlyContinue }
            if (@(Get-Topside).Count -gt 0) { Problem 'Tacheo Topside would not close. Restart the PC, then run this before opening Topside.'; return 1 }
            Say 'Topside closed. PLUG THE UNIT BACK IN NOW.' 'Yellow'
        } else { Say 'Closed.' }
    }

    Step 'Looking for the unit on USB'
    $units = @(Get-UnitPorts)
    if ($units.Count -eq 0) {
        Say 'Plug the unit into this PC with a USB-C DATA cable (some cables only charge).'
        Say 'It can be on or off. Waiting up to 60 s ...'
        $until = (Get-Date).AddSeconds(60)
        while ($units.Count -eq 0 -and (Get-Date) -lt $until) { Start-Sleep -Milliseconds 500; $units = @(Get-UnitPorts) }
    }
    if ($units.Count -eq 0) {
        Problem 'No unit found. Try another USB-C cable (some only charge) or another USB port, then run this again.'
        return 1
    }
    if ($units.Count -gt 1) {
        Say ('More than one unit is plugged in: ' + (($units | ForEach-Object { $_.Port + ' (' + $_.Mode + ')' }) -join ', '))
        $pick = Read-Host 'Type the COM port to update (e.g. COM7)'
        $units = @($units | Where-Object { $_.Port -eq $pick.Trim().ToUpper() })
        if ($units.Count -eq 0) { Problem 'That port is not one of them.'; return 1 }
    }
    $unit = $units[0]
    Say ("Found it on " + $unit.Port + " (" + $unit.Mode + ").") 'Green'
    $all = @(Get-UnitPorts)
    if ($all.Count -gt 1 -and $unit.Mode -ne 'running' -and $null -ne (Find-Sap6Drive)) {
        # a SAP6 on Phil's firmware has the bootloader's USB IDs: with another unit plugged in, which is which can't be told
        Problem 'A SAP6 with Phil''s firmware is plugged in as well. Unplug every other unit, then run this again.'
        return 1
    }
    if ($unit.Mode -eq 'circuitpython') {
        Problem ("This is a SAP6 with Phil Underwood's firmware (its drive is " + (Find-Sap6Drive) + ").")
        Say 'To convert it to Tacheo, open "Tacheo Topside.exe" and use its SAP6 page:'
        Say 'it backs up the SAP6''s drive first and carries Phil''s settings over. Nothing was changed.'
        return 1
    }

    $bootPort = $null
    $fw = $null
    if ($unit.Mode -eq 'bootloader') {
        Say 'It is already in its bootloader (an earlier update did not finish). It can''t say which unit it is.'
        $build = Ask-Board
        if ($build -eq '') { Say 'Nothing changed.'; return 0 }
        $fw = Get-NewestFirmware $FwDir $build
        if ($null -eq $fw) { Problem-NoFirmware $build; return 1 }
        Say ("Installing " + $fw.File.Name + " now.")
        $bootPort = $unit.Port
    } else {
        $id = Get-UnitId $unit.Port
        $build = 'breadboard'
        if ($null -ne $id -and $id.Build -ne '') { $build = $id.Build }
        elseif ($null -eq $id) {
            # no answer (busy, hung, or firmware older than 0.4): the build can't be read, so ask - a wrong build would stick
            Say 'The unit did not say which build it runs.'
            $build = Ask-Board
            if ($build -eq '') { Say 'Nothing changed. Switch it off and on, then run this again.'; return 0 }
        }
        $fw = Get-NewestFirmware $FwDir $build
        if ($null -eq $fw) { Problem-NoFirmware $build; return 1 }
        Say ("New firmware: " + $fw.File.Name)
        if ($null -ne $id) {
            Say ("On the unit: " + $id.Name + " " + $id.VersionText + " (" + $id.Build + " build)")
            if ($null -ne $id.Version -and $id.Version -ge $fw.Version) {
                if (-not (Ask-YesNo ("It already has " + $id.VersionText + ". Install " + $fw.Version + " anyway?") $false)) { Say 'Nothing changed.'; return 0 }
            } else {
                if (-not (Ask-YesNo ("Install " + $fw.Version + "?") $true)) { Say 'Nothing changed.'; return 0 }
            }
        } else {
            Say 'The unit did not say its version (firmware older than 0.4, or busy).'
            if (-not (Ask-YesNo ("Install " + $fw.File.Name + "?") $false)) { Say 'Nothing changed.'; return 0 }
        }
        Step 'Switching the unit to its bootloader'
        $bootBefore = @(Get-UnitPorts | Where-Object { $_.Mode -eq 'bootloader' } | ForEach-Object { $_.Port })
        # 1.6.52 (Paul's old SAP6, 2 Nov 2026): a frozen unit often restarts as the port opens, and Open then fails with "A device
        # attached to the system is not functioning" - the touch still worked. An error only counts if no bootloader turns up.
        $touchErr = $null
        try { Send-Touch1200 $unit.Port } catch { $touchErr = $_.Exception.Message.Trim() }
        $bootPort = Wait-ForMode 'bootloader' 20 $bootBefore
        if ($null -eq $bootPort -and $null -ne $touchErr) { Problem ("Could not open " + $unit.Port + " (" + $touchErr + "). Close Tacheo Topside, the Arduino Serial Monitor or any other program using it, then run this again."); return 1 }
        if ($null -eq $bootPort) { Problem 'The bootloader did not appear. Unplug the unit, plug it back in and run this again.'; return 1 }
        Say ("Bootloader is on " + $bootPort + ".") 'Green'
        Start-Sleep -Milliseconds 800
    }

    Step ('Sending firmware ' + $fw.Version + ' (about 20 s)')
    # Windows PowerShell 5.1 turns a native tool's stderr into errors; don't let that stop us.
    $eap = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    $out = & $NrfUtil --verbose dfu serial -pkg $fw.File.FullName -p $bootPort -b 115200 --singlebank 2>&1
    $code = $LASTEXITCODE
    $ErrorActionPreference = $eap
    $out | ForEach-Object { Add-Content -Path $LogFile -Value ([string]$_) -ErrorAction SilentlyContinue }
    if ($code -ne 0) {
        ($out | Select-Object -Last 6) | ForEach-Object { Say ([string]$_) 'DarkYellow' }
        Problem 'The update did not finish. The unit is safe in its bootloader: unplug it, plug it back in, and run this again.'
        return 1
    }
    Say 'Firmware sent.' 'Green'

    Step 'Waiting for the unit to restart'
    $appPort = Wait-ForMode 'running' 25
    if ($null -eq $appPort) {
        Problem 'It did not come back on USB. Unplug it, plug it back in, and run this again to check.'
        return 1
    }
    Start-Sleep -Milliseconds 1500
    $id = Get-UnitId $appPort
    if ($null -ne $id) {
        Say ("Now running: " + $id.Name + " " + $id.VersionText + " (" + $id.Build + " build)") 'Green'
        if ($null -ne $id.Version -and $id.Version -ne $fw.Version) { Say 'That is not the version just sent - run the updater again.' 'DarkYellow' }
        if ($null -ne $id.Version -and $id.Version -ge [version]'0.6') {
            Say ''
            $nm = Read-Host "Owner's name for the start-up greeting (Enter = leave it as it is, - = no name)"
            if ($nm -ne '') {
                if ($nm -eq '-') { $nm = '' }
                $nm = ($nm -replace '[^ -~]', '').Trim()
                if ($nm.Length -gt 15) { $nm = $nm.Substring(0, 15) }
                if (Set-OwnerName $appPort $nm) { if ($nm -eq '') { Say 'Name cleared.' 'Green' } else { Say ("Name set: " + $nm) 'Green' } }
                else { Say 'The unit did not confirm the name - try the updater again.' 'DarkYellow' }
            }
        }
    } else {
        Say 'It restarted (it did not report its version - check Menu > Info > About).' 'DarkYellow'
    }
    Say ''
    Say 'DONE. You can unplug it. Settings and calibration are kept.' 'Green'
    Say 'After a firmware update, do Menu > Calibrate > Check before the next trip.'
    return 0
}

if ($MyInvocation.InvocationName -ne '.') {
    $rc = 1
    try { $rc = Main | Select-Object -Last 1 } catch { Problem ("Unexpected error: " + $_.Exception.Message) }
    exit $rc
}
