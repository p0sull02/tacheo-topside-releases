﻿﻿TACHEO
==============
Tacheo for Windows 10 and 11 (called Tacheo Topside before 1.6.113). Nothing to install: double-click
"Tacheo Topside.exe". Keep the whole folder together (firmware\, manuals\, sap5\, sap6\ and tools\ are used).

The first time, Windows may say "Windows protected your PC" (the program isn't signed by a
paid certificate). Click "More info", then "Run anyway". It only asks once.

CARTOTABLE (Tacheo 1.6.92 - 1.6.105): projects are one file, <cave>.ctproj - the data, sketch scans and your Illustrator
  and PDF map drafts in it; File > Share Project writes that one file; .ctproj files have their own icon and open with a
  double-click. Declination is worked out for every trip from its date with the most precise model (IGRF-14 plus the
  WMMHR2025 crustal field). No GPS for the entrance? Place on the map > Find it on a map: type a town, then click the
  entrance on the lidar hillshade; Look it up fills the elevation. Opening a cave can be cancelled (or Open another cave).
  Drafted PDF / Illustrator maps line up under the line plot by themselves; a heat map of the ground; big caves open much
  faster; Publish to web makes a read-only page of the cave; Phone link sends caves to the Tacheo phone app.
TACHEO PHONE APP 1.7 (Android; get it from Tacheo's Connect a phone page): two or more Tacheos at once, one-way
  messages to a unit's screen, each unit's battery and signal (long range switched on by itself when the signal gets weak),
  and sketching as you survey with cross sections.
TACHEO 1.6.119: an update that gets stuck on the unit's update drive now finishes by itself - if the unit is still in update
  mode after the install (a drive that took an earlier file keeps waiting until a reset), Tacheo sends the same firmware over
  the unit's USB serial port instead. CartoTable: Home shows a snapshot of the data issues, and Do everything stays green and
  "complete" while nothing has changed since it ran; Devices has its own page (and a place on the left menu); instrument
  corrections and compass courses - each entry dated, in effect from its date until that instrument's next, added or deleted
  but never edited - are applied when the cave compiles (and in Reckon). Map and GIS opens on soft shaded relief with closed
  hollows outlined in blue and 10 ft contours (labelled 50 ft lines); the big green Run gets the elevation and writes the GIS
  overlay, shaded relief, sinks and contours into Documents\CartoTable\<cave>\GIS\<date>.
  Unit firmware: Tacheo 1 colour 1.17.21 (READY shows which phone is linked; carries the fast Bluetooth update for when the
  phone app's updates come back); Tacheo 1 OLED and SAP5 colour 1.17.14; SAP6 1.17.13.
TACHEO 1.6.116: CartoTable's Survey data page is redesigned: each trip is a card, the readings you wrote in the book (front
  sight and backsight) are in bold with a green / amber / red chip for how well they agree, and the value the survey uses sits
  grey underneath. L R U D are columns (the From station's); an end station shows its own LRUD line, or, when none was taken,
  the station before's, marked "LRUD assumed". "+ Add a line" opens the survey file with the next leg started: type the
  length, Enter, the front sight, Enter, the backsight, and so on through L R U D, then the next station is filled in for you
  (clear the To to give the last station its own L R U D). A leg whose front and back sights disagree badly now uses the sight
  the loops back instead of their average (the page says which). Sketches: Read can use Claude, ChatGPT, Gemini, Azure
  OpenAI (Copilot's models) or any OpenAI-compatible server - "Choose the AI..." beside the Read button, your own API key.
  Unit firmware unchanged: 1.17.14 (Tacheo 1 OLED and colour, SAP5 colour), SAP6 1.17.13.
TACHEO 1.6.115: CartoTable has a Devices page (Home > SURVEY DATA > Devices): every instrument and every calibration - your
  Tacheos' records from Devices (calibration ID, accuracy, fit, worst hold, compass and gravity fit, field, dip, temperature)
  and any other instrument you add or import (a DistoX, a SAP, a compass pair, or a Tacheo calibration record). Set which
  calibration read each survey file's front sights and backsights (or put ";@instrument FS=<ID> BS=<ID>" in the file):
  Reckon then holds that file to the calibration's own figures and names it in its report. The phone app's Sketch card is now
  on the Survey tile's page. Unit firmware in this release: 1.17.14 (Tacheo 1 OLED and colour, SAP5 colour), SAP6 1.17.13.
TACHEO 1.6.114: CartoTable opens on a home page of your caves - pick one to open (it no longer reopens the last cave by
  itself; Settings > "Open the last cave at start" turns that back on). A cave you've compiled before opens almost at once:
  the adjustment and Reckon's findings are kept and only redone when its survey files change. Elevation comes from the
  agency for the state the cave is in (KyFromAbove in Kentucky, West Virginia's 1 m lidar, USGS 3DEP elsewhere). Sketches:
  "Read with Claude" reads the station names off a sketch page and places it (uses your own Claude API key), "Import station
  reads" and a check window for every placed page. GIS area export (PNG, line plot over PNG). The phone page's sketching
  draws like Illustrator - smooth curves, editable anchors, your brushes and swatches at map scale. Unit firmware unchanged
  (1.17.11); side-lead names like A25-B need unit firmware 1.17.14, which isn't out yet.
TACHEO 1.6.113: Topside is now called Tacheo - the program on the computer and the phone app. The welcome screen's card for
  your units is Devices; the units are the TD-1 and TD-2; Updates and Upgrades has the tabs TD, SAP6, SAP5 and Tacheo. Your
  settings, shots and calibration records stay where they are; folders that were named Topside (Documents\Topside\From phone,
  and on the Store and Mac versions Documents\Tacheo Topside) move to their new names the first time 1.6.113 starts. The
  program file is still "Tacheo Topside.exe" for now. Also in it: MapViewer - your cave's drafted maps on the line plot,
  tap a quad and its newest map comes up, shared as one map pack - and firmware installs that go through the unit's update
  drive when it shows one. Unit firmware as in 1.6.110 (1.17.11).
TACHEO 1.6.110: CartoTable - the survey file opens as a spreadsheet you can edit (front sights and backsights in cells
  of their own, units in the headings), and Side by side puts each shot's row from the field book beside it. Profiles of any
  boxed area (projected, extended, hybrid), a Statistics and data page with each survey's BCRA grade, the tie-in check, a
  Point cloud page for cave scans (LAS, PLY, XYZ), "Will they connect?" for two passages, and a Cartography page: quadrants
  with a cartographer and a status each, and every quadrant exported at once. Drafted maps keep their transparency, are cut
  to their map frame, the newest sheet wins, and they can be seen alone. Do everything asks where to look when a step finds
  nothing; Field books > Add book scans. Survey prefixes are off the names on screen (a switch brings them back), the pages
  are grouped into fewer, and the Data clinic keeps its work between versions. Carries Tacheo firmware 1.17.11: the phone
  app's Cross section button opens Cross section on the unit.
TACHEO 1.6.109: CartoTable reads your field book. Scans or phone photos of the CRF green data form are read (shots and
  left/right/ceiling/floor) and checked against the survey files; the Data clinic is its own window, findings filed by type,
  each beside its book row and survey line, with corrections shown before they are made. New on Home: Do everything (sort
  the trips, compile and Reckon, check the books, scan for errors, a summary PDF - each step animated), a chip per cave
  when a project holds several, and the guide and project checklist. Leads written in the book (P), shots written in its
  notes and writing on sketches are shown in the clinic; ;Lead comments are on the Leads page.
TACHEO 1.6.108: new Tacheo and SAP6 firmware now comes straight from the internet - when Tacheo starts and when a
  unit is plugged in or connected, it downloads anything newer for your units, and a bar at the top says "New firmware
  for TCH-..." with Update it. No new Tacheo needed for new firmware. The phone page (Phone link) has the phone app's
  online maps and the sketch and data scanner.
TACHEO 1.6.107: 1.6.106 closed as soon as it opened on Windows, so its update put 1.6.105 back. 1.6.107 is the same
  Tacheo and firmware, built correctly.
UNIT FIRMWARE: Tacheo 1.17.9 for the TD-1 (OLED and colour screen) - CrossTalk no longer gets stuck on "Waiting:";
  1.17.8 (messages from the phone) for the SAP5 with the colour screen; SAP6 1.16.30.5 (messages for the SAP6).
UPDATES: Tacheo now updates itself from GitHub (no more antivirus warnings from the old update script).

CARTOTABLE (Tacheo 1.6.89 - 1.6.91): one viewer - tick Rotate in 3-D on the view bar to turn the plot into the 3-D
  cave from where it is; Layers (top left of the plot) turns names, marks, search areas and map layers on and off;
  Survey data opens on your field books; the Data clinic can check an area you draw round; Reckon's corrections are
  only offered when the loops agree; every trip is graded; no text is ever cut off; the last cave opens at start.
CARTOTABLE (Tacheo 1.6.88): Trip planner tile on Home. The planner shows time walking, stooping, crawling on hands
  and knees, belly crawling, in breakdown, climbing and on rope; click a lead for its whole text, when it was last pushed
  and by whom (add their phone/email from the card); Resurvey gives the stretch of a bad loop worth redoing in one trip;
  Change / Previous trip / Swap fix a wrong pick. Any table: hover a cut-off cell, or click the row, to read it in full.
CARTOTABLE (Tacheo 1.6.87): 3-D cave - SURFACE shows the ground over the cave from the elevation model (Off,
  See-through, Solid), with contours; click a station and dragging turns the cave round it; full detail while dragging.
  Home scrolls on a small window. Trip planner: Print the brief / Save the brief as PDF next to the plan.
CARTOTABLE (Tacheo 1.6.86): 3-D cave - click a shot to select it (Ctrl adds, Alt+click for a lasso), drag orbits the
  selection, Shift-drag looks round, Shift+right-drag walks, Alt+wheel cuts a section; O plan, P profile along the
  selection, S zoom to it, E everything. Find takes AJ51, AJ50-60, AJ50+, trip names, team or notes; Shots table lists
  the matches; double-click a shot for its survey notes.

CARTOTABLE (Tacheo 1.6.85): 3-D cave (on Home and the left rail): the passages built solid from the LRUDs - drag to turn,
  right-drag to move, wheel to zoom; click a station and the cave lights up by distance along the survey from it; Profile looks
  side-on at that passage; Fly moves you through with W A S D, Q E; Find takes you to any station; Save picture.

CARTOTABLE (Tacheo 1.6.82): click a shot, then "Float its traverse" to see it hung from either end - it names a tie
station that was probably booked under the wrong name. Trip reports now print at the end of the cave report.

CARTOTABLE (Tacheo 1.6.81): Trip planner (on the left): pick a start and a destination; the route with times, the leads on
the way and what to expect at each, weak survey to resurvey, trip ideas, and a printable brief.

CARTOTABLE (Tacheo 1.6.80): every survey needs a prefix. Opening a cave with surveys that have none asks for one per survey
(required); Walls files get a #Prefix line (.bak kept) and tie-in stations stay joined.

CARTOTABLE (Tacheo 1.6.79): Reckon's corrections are drawn on the line plot before they are made (red dashed = now, green =
after); OK makes them and the plot becomes the corrected one; Export report writes a before/after PDF for the data team.

CARTOTABLE (Tacheo 1.6.78): map symbols stay the size they would be on a paper map as you zoom out, instead of growing over
the passages; clicking a flagged shot shows only what caused the flag, as a picture (verdict, two meters, the three readings).

CARTOTABLE (Tacheo 1.6.77): saving a typed trip now compiles it like Walls - Reckon lists what it found in the trip; tick to fix,
untick to accept. Enter a trip starts in feet with the book prefix filled in. Home has one tile per job.
CARTOTABLE (Tacheo 1.6.76): with elevation loaded on Map and GIS, a station shows how far below the ground it is; Profile cut
(on the layers dock) - click points across the map, then Ground profile along this line: the hillside with the passages under it.
CARTOTABLE (Tacheo 1.6.75): Exports (left menu, and a Home tile) - pick the whole cave or Draw a box on the plot, tick the formats
(plan, profiles all round, extended, sections, 3-D, Walls/Compass/Survex/Therion, CSV, GeoJSON, shapefiles, KML, GPX, map sheet,
report, and a printout of the map with its layers as PNG and PDF), then Export the chosen... - one new folder holds them all.
CARTOTABLE (Tacheo 1.6.74): Trip review (left menu, and a Home tile) - every trip with what it has (book pages, report, photos, closure
  score), the picked trip's report, book, survey file, side by side, photos and "Check the book" (each data page read and checked against
  the survey file: red where a number may have been typed wrong), with the plot narrowed beside it. "Sort book scans into trips" files a
  whole folder of scans or photos (loose pictures or scanned-book PDFs) by the stations on each page, its name and date, and the pages
  around it. Home is dark, each tile its own colour. Map and GIS is its own workspace: a layers dock beside the plot, map layers drawn only
  there, the pointer's coordinates and ground height. The Leads page shows the leads first. Fixed: lead search rings covering the map on a
  big cave; colours washing out on the dark plot; uncertainty now green-to-red and heavier where it's worse; contours pan smoothly; the
  window opens maximized on a smaller screen.
CARTOTABLE (Tacheo 1.6.72): "Read this page" copes with pencil, smudges, a photo taken a little turned (straightened first), slashed
  zeros and barred sevens. It reads each cell three ways and turns it amber when they disagree; the box after reading lists each column,
  least sure first. Right-click an amber cell for the other ways it could read (one that matches the other sight says so).
CARTOTABLE (Tacheo 1.6.71): Enter a new trip > "Read this page" reads the numbers off the book data page on show (the page photos
  picked on the right) into the grid; cells it isn't sure of, or that fail a check, are amber - check every row against the book. Also
  since 1.6.67: a folder opens (its project, or its loose .srv files as one cave); the ground draws about 7x faster; lead search areas on the
  Map page; seasonal water and sump symbols; a pit's depth in a circle and a dome's height in a square; saved annotations show at once and
  read on the dark plot. Unit firmware unchanged.
CARTOTABLE (Tacheo 1.6.67): Map and GIS > "Get elevation online" fetches the ground around the cave (USGS 3DEP lidar, 1 m
  where flown, in the US; free global terrain tiles elsewhere), asks first, saves it as a GeoTIFF in Documents\CartoTable\<cave>\elevation
  and makes the hillshade, a colour relief (elevation colours lit by the hillshade), contours with labelled index lines, sinks and cliffs.
  The Rock units dialog now explains itself (it is optional). Unit firmware unchanged.
CARTOTABLE (Tacheo 1.6.66): Reckon is now part of CartoTable - its own page and menu entries are gone. "Cartography and GIS" at the
  bottom of the left menu opens CartoTable, and a Walls project (.wpj) or .srv dropped on Tacheo opens there. CartoTable's Compile runs
  Reckon, and "Repair the data" (beside the closure score) steps through every problem and Reckon's corrections. New in CartoTable:
  the cave's own line plot on its Home page, a Back button, satellite and other base maps on the Map page, a dark plot, a legend,
  loops listed in the inspector, and lead sizes beside the lead symbols. Unit firmware unchanged from 1.6.65.
CARTOTABLE (Tacheo 1.6.65): the CartoTable card on the welcome screen opens CartoTable - survey reduction (Walls, Compass,
  Survex, Therion), the closure score, Reckon, the map and sinkhole finder, sketches, cross sections, annotations and Start drafting.
UNIT FIRMWARE IN THIS TACHEO (1.6.65, the same as 1.6.64, in firmware\): the TD-1 with the OLED (cave build) 1.17.6; the TD-1 with the
  colour screen (cavec build) 1.17.5; a SAP5 with a XIAO and the colour screen (sap5xc build) 1.17.4; a SAP6 running Tacheo
  (sap6 build) 1.16.30.4; SAP5 firmware 2.2.16 (in sap5\).
  Each unit is offered only its own build (Updates and Upgrades > Tacheo); what each one changes is in the .txt beside its zip.
  The lines below are the history of earlier firmware.
UNIT FIRMWARE SAP6 1.16.30.4 (Tacheo 1.6.64, a SAP6 running Tacheo):
  - The battery no longer runs down while switched off: the SAP6 stays in its low-power standby (as the TD-1 does) and a
    double-click brings it straight back. It goes fully off only when the cell is nearly flat (under 3.45 V), to protect it.
  - Simpler menus: Main is Survey, Tools, Calibrate, Bluetooth, Settings, Device, Turn off; the rarely used settings are under
    Settings > Advanced.
UNIT FIRMWARE 1.17.6 / 1.17.5 (Tacheo 1.6.62 / 1.6.63, the TD-1 - OLED 1.17.6, colour screen 1.17.5):
  - OLED: the battery no longer runs down while switched off. Switched off, it stays in its low-power standby (as the colour
    screen has since 1.16.96) and a double-click brings it straight back to READY. It goes fully off only when the cell is nearly
    flat (under 3.45 V), to protect it.
  - Both: bench-test commands for the builder's computer (nothing changes on the unit for you).
UNIT FIRMWARE 1.17.4 (Tacheo 1.6.60, the TD-1 - colour screen and OLED - and the SAP5 with the colour screen):
  - FIXED: the colour screen restarted on every front shot (1.16.93 - 1.17.1). This was the crash after a shot.
  - The laser is off at every switch-on: the first press lights the dot, the next takes the shot.
  - Cross sections are always drawn closed, on the unit and in Tacheo.
  - A crash or freeze now keeps its record through the restart: send a Tacheo report to Sully if it ever happens.
  - Colour screen: three new start-up messages. OLED: still goes fully off after 2 hours switched off.
UNIT FIRMWARE 1.17.0 (Tacheo 1.6.59, the TD-1 - cave and cavec): the laser dot no longer goes out by itself on READY. On
  some units the laser module put its own dot out after about 13 seconds; the Tacheo now tells it to stay on every 5 seconds
  while READY. If a unit restarts unexpectedly (a crash), it now records where it happened - send a Tacheo report to Sully.
UNIT FIRMWARE 1.16.99 (Tacheo 1.6.58, the TD-1 - cave and cavec): Autoflip is Off by default, and switched off once on units
  already set up - on the Tacheo it only ever turned the picture over when the unit was stood on its tail. Set the picture for
  your hand in Settings > Screen (Right hand / Left hand). Turned back On in Settings > Autoflip, it stays On.
  With 1.16.98 (first in this version of Tacheo): the laser dot stays lit on READY (no time-out); take a shot to put it out. The colour
  unit stays in its low-power standby instead of going fully off, and keeps logs of its time switched off for Sully.
UNIT FIRMWARE 1.16.92 (Tacheo 1.6.54, colour screen / cavec and sap5xc): IRON INVADERS, the calibration game - Menu > Calibrate,
  the first row (PLAY, green, with a saucer). Tip and turn the unit to roll the sight onto an alien ship and hold still: it fires
  itself. Each ship shot down is a quiet compass reading; once enough are down the MOTHERSHIP comes, and if the readings show the
  compass has drifted the unit offers a compass-only top-up, proved on a real mark first (Save starts on No; the game's Options
  have Undo top-up). It never touches the laser aim, the clino or distances. The colour pages' large fonts now live on the
  unit's 2 MB chip: Tacheo 1.6.54 puts them there the first time the unit is plugged in (plainer fonts until then). FIXES: a
  calibration that failed with "Out of memory" at the end; a still shot asking "Moved 2924 deg" (the colour TD-1's
  microsecond clock went back to 0 every 67 s).
UNIT FIRMWARE 1.16.84 - 1.16.87 (Tacheo 1.6.51, colour screen / cavec and sap5xc): THE BATTERY DRAIN WHILE OFF, FOUND AND FIXED.
  Measured with a meter in the battery lead, standby drew about 13 mA: the log flash chip and the chip's hardware blocks were left
  running. Now, switched off and unplugged for 2 s, the unit closes the flash and switches those blocks off - about 0.15 mA on the
  same meter - and sets them back when it is plugged in or double-clicked on. Nothing you see or do changes. Also on the colour
  TD-1: Settings > POWER > Standby 30 min / Off (Off: Power off goes fully off ~2 s later, for testing), and Device > Drain
  test (the last row) - with a meter in the battery lead, six 15-s steps marked by beeps, the steps' details in the Diagnosis
  report (DRAINTEST). The sap5xc goes out in the release from 1.6.51 on.
UNIT FIRMWARE 1.16.83 (Tacheo 1.6.49, colour screen / cavec): the LRUD slot - along the bottom of READY and of each result, the
  station's name, then L, R, U and D with their distances ("--" for one not taken yet), so you can read all four off to the
  sketcher at once. Leg track on: the LRUDs of the station the unit is At (the newest of each; a leg that moves the unit on starts
  the next station's empty; they come back after switching off and on). Leg track off: the LRUDs since the last long shot.
UNIT FIRMWARE 1.16.80 - 1.16.82 (Tacheo 1.6.48, colour screen / cavec): switched off and unplugged, the unit goes fully off
  after 30 min in standby (was 2 h) - a few microamps instead of a few mA; a double-click still turns it on (a cold start: the
  survey in progress ends there, as after 2 h before). HOW A SHOT IS TAKEN CHANGES AGAIN - on a result, one
  tap goes back to READY, and a tap on READY starts the countdown (1.16.77 - 1.16.79 started it straight from the result); a
  half-second hold on a result is still an LRUD, two taps the menu. Fixes from the beta reports: in Survey > Recall shots a long
  tap leaves from any shot and a tap goes to the next older one (round to the newest after the oldest) - before, you could get
  stuck in it; LRUD Left and Right after a backsight are judged the way the survey runs (they came out swapped), on the CrossTalk
  BS unit too; a calibration's roll on a mark allows 12 deg between holds before the unit is calibrated and 8 after (it said
  "Target lost" display down). NEW: a good backsight (within the backshot angle and 0.10 ft) plays the happy beep, as FSx3 Good.
UNIT FIRMWARE 1.16.75 (Tacheo 1.6.46, colour screen / cavec): the off-drain finder - units lose a few mA switched off, where
  it should be microamps. 1.16.75 records why on every unit: each wake from fully off (also those that go straight back off
  without a double-click), the pin that woke it, every pin's state at switch-off and at fully off, and how much of standby the
  processor is awake. Going fully off also lets go of every plain input. Testers: leave the unit off overnight, then switch it
  on, plug it into Tacheo and send a Diagnosis report (it shows OFFDIAG and OFFPINS). Nothing you see or do changes.
UNIT FIRMWARE 1.16.71 - 1.16.74 (Tacheo 1.6.45): AFTER INSTALLING 1.16.73 or 1.16.74 DO A NORMAL CALIBRATION (the unit shows
  RECALIBRATE at start-up until you do; any press skips it). Quiet compass reads - Bluetooth advertising and scanning pause
  for every compass reading, and for held legs, phone / Sketch shots and calibration holds the laser's regulator is off too;
  a held leg keeps reading until its average settles (up to 50 samples or 1.5 s); Noise test (cave: Info > Noise test; cavec:
  Device > SENSORS > Noise test) - testers, run it once at home and once in the cave and send the report from Tacheo; cross
  sections one tap per aimed shot, with no outlier rule. Colour screen (cavec) 1.16.74 also: Tools > Temperature - the chip's
  temperature, the tilt sensor's, the temperature at the last calibration and how far it has moved since (green / orange /
  red; past 15 C every shot carries TEMP). 1.16.72 (cavec): USB command FSFORMAT, which remakes the storage of a unit whose
  saves all fail and writes back its serial number and settings.
UNIT FIRMWARE 1.16.12 (Tacheo 1.6.33): Tools > Sketch leaves a small solid square (2 x 2 pixels) where each
  shot's line ends, kept when the line is cleared, so the features shot from a station build up on the page where they lie
  (2 > Clear squares, or a restart, clears them); the Tools menu is Sketch, Field meter, Strike & dip, Point-to-point,
  Rigging, Live tape, Elevation; Turnaround is gone; Depth is now called Elevation (the same tool). SAP5 firmware 2.2.16 (in
  sap5\): the same Sketch squares, Tools order and Elevation, with 2.2.13's charge screen and battery LIFE.
UNIT FIRMWARE 1.16.9 (Tacheo 1.6.32): charging while switched off, the screen shows the battery as a big
  bar with the % under it, a bolt while charging, and the battery's life left and charge cycles; dim, and it moves a pixel
  or two each minute. Charged: 100 % for 10 minutes, then dark. Unplugged: dark at once, fully off at 2 hours as before;
  plugged in while fully off it wakes quietly into the charge screen and goes fully off again 3 s after unplugging.
  Battery life left = the smaller of 300 charge cycles and the cell's health from how long a charge takes. Cave units also
  get the laser station (Calibrate > Factory > Laser station) and the rear rod-tip laser offset for new units.
UNIT FIRMWARE 1.16.7 (Tacheo 1.6.27): Tools > Sketch - the bearing scale is numbered at N, 90, 180 and 270
  only (the 45-degree marks stay, unnumbered); beside the page the azimuth, Dist (the distance as shot) and HD (the
  horizontal distance) - the Draw line is gone. SAP5 firmware 2.2.12 (in sap5\): the same Sketch change, with Sketch,
  Live tape, Depth, Strike & dip and the battery % from 2.2.11.
UNIT FIRMWARE 1.16.6 (Tacheo 1.6.24): FIX - 1.16.5 crashed every time it started. A unit stuck on 1.16.5:
  plug it in, press the XIAO's reset button twice quickly (update mode: the XIAO-SENSE drive), then Updates and Upgrades >
  "Install on the unit in update mode". Everything else as 1.16.5.
UNIT FIRMWARE 1.16.5 (Tacheo 1.6.23): one battery % on every screen and in Tacheo, which only goes down on
  battery (no 75 % falling to 55 % after unplugging) and reads 100 % after a full charge (the unit learns what full reads:
  Info > Battery "Full"); a calibration interrupted by a freeze or crash can be resumed from the next hold; a freeze
  records where it was stuck (send the report to Sully); FIX - a laser reply that never ended could freeze the unit; the
  screen starts the right-hand way (buttons on the right of the picture; Settings > Screen = Right hand / Left hand).
UNIT FIRMWARE 1.16.4 (Tacheo 1.6.22): the battery % while charging starts where it was on battery and
  only goes up (the SAP6 read about 15 % high on USB before); Tools > Sketch scale in feet to the inch (1 in = 20 ft by
  default; a 14 ft shot draws 0.7 in), Draw in inches; button hints only on the calibration screens and the tutorial.
UNIT FIRMWARE 1.16.3 (Tacheo 1.6.21): Tools > Sketch reworked - shots taken while moving are kept, no
  Autoflip while it is open, a Rite in the Rain page (4 5/8 x 7 in, sideways) with a dotted 1-inch grid and a bearing scale
  round the edge, one line from the station (1 clears it), Exit Sketch in the options. SAP6s running Tacheo now keep their
  shots and logs on the XIAO's 2 MB chip too (it held Phil's original files: the backup in SAP6 backups\ is their copy).
UNIT FIRMWARE 1.16.2 (Tacheo 1.6.20): Tools > Sketch (a to-scale sketch page: 1 press = laser, next press = instant shot,
  a line along the azimuth at the horizontal distance; scale 1:20 default, North on any side); READY without the button
  hints or Laser on / off.
UNIT FIRMWARE 1.16.1 (Tacheo 1.6.19): READY shows the battery % under the battery symbol, also while charging. Cave units:
  the shot log, trip log and saved calibration holds move to the XIAO's 2 MB flash chip (the newest 10,000-20,000 shots
  are kept, was 200-400; existing logs are moved across at the first start); the buzzer no longer hums between beeps;
  the lit SHOT button (dark during every compass reading).
UNIT FIRMWARE 1.15.1 (Tacheo 1.6.16): the Crosscheck pair page shows your own shot in big figures (as
  every result screen does), with the other unit's reading and BS minus FS small on the right of each.
UNIT FIRMWARE 1.15.0 (Tacheo 1.6.15): Crosscheck pair page - the FS shot, the BS shot and BS minus FS
  (azimuth BS - (FS + 180), inclination BS + FS, distance BS - FS) once a shot is paired, out-of-tolerance figures
  inverted, READY showing the pair 15 s; Menu > Pairing > Role (Auto / FS / BS) - set on one unit, the partner Tacheo
  takes the other; FIX - the partner's shot of the next leg is no longer compared with yours of the leg before.
UNIT FIRMWARE 1.14.2 (Tacheo 1.6.14): FIX - switching on from standby no longer restarts the unit (the
  start-up screen twice, the second calibration screen upside down); the start-up screens follow Autoflip; 2 hours after
  being switched off the unit goes FULLY OFF and draws almost nothing (double-click or USB turns it on, a moment slower,
  clock lost); a survey ends after 2 hours with no shot (was 4). SAP5 firmware 2.2.10 (in sap5\): its start-up pages
  follow Autoflip too.
UNIT FIRMWARE 1.14.0 (Tacheo 1.6.12): Menu > Pairing > Other instr. on the Tacheo - Crosscheck with a
  BRIC4/5, Cavway X1, Disto XBLE, SAP6 (Phil's firmware) or SAP5, read over Bluetooth (see the manual's "Crosscheck with
  another instrument"); and the phone link now takes SexyTopo's and TopoDroid's acknowledgement.

TACHEO 1.6.53: carries unit firmware cavec 1.16.90 - the battery % on USB from each unit's own charging lift (a 4-cell unit read
  about 10 % low when plugged in), and the freeze recorder's step. The report's "while switched off" battery figure leaves out
  standbys spent charging on USB (they made a draining unit read "Holds its charge"), and a power-on that froze before anything
  was logged is now reported.
TACHEO 1.6.52: RESCUE A FROZEN UNIT. When a unit's firmware has frozen (an update that went wrong can do that), Windows still
  lists it but it answers nothing. Tacheo used to show nothing and hang on it (until the unit was unplugged); now the top of the
  window says "A unit on COMx isn't answering", and Updates and Upgrades rescues it: "Force update mode" (TD tab, and now
  SAP6 > Updates too), then install - or the install button straight away ("Install on the unit that isn't answering"). The
  TD tab's which-unit question offers the SAP6 too. "Update firmware only.cmd" does the same rescue without Tacheo (it closes
  Tacheo first, which holds the unit's port). Help: "Windows sees my unit but Tacheo doesn't". Unit firmware unchanged.
TACHEO 1.6.51: carries unit firmware cavec 1.16.87 and sap5xc 1.16.87 (the battery drain while off - see above); the trip log
  names the Drain test's switch-off. Nothing else changes in Tacheo. cave 1.16.73, sap6 1.16.30 and SAP5 2.2.16 unchanged.
TACHEO 1.6.50: Install update gets past Google Drive's "Download anyway" page by itself (the Mac zips are too big for Drive's
  virus scan, so on a Mac the update stopped with "Google Drive sent a web page instead of the file"). On a Mac, "Open the
  download page" opens the Mac folder. Unit firmware unchanged (cavec 1.16.83, cave 1.16.73, sap6 1.16.30, SAP5 2.2.16).
TACHEO 1.6.49: carries unit firmware cavec 1.16.83 (TD-1, colour screen: the LRUD slot - see above); nothing else changes.
TACHEO 1.6.48: carries unit firmware cavec 1.16.82 (TD-1, colour screen - see above); cave 1.16.73, sap6 1.16.30 and
  SAP5 2.2.16 unchanged. The trip log's fully-off notes say 30 min for the colour screen. On a Mac, Diagnosis > "Send to Sully" now sends the whole
  report (before it opened a cut-short email with nothing attached).
TACHEO 1.6.47: Updates and Upgrades > Tacheo > "Force update mode" - puts the plugged-in Tacheo in update mode without its
  reset button (a frozen unit too); then "Install on the unit in update mode" asks which unit it is, so any build can go on it
  (the way to change a unit's build). In that question "TD-1, colour screen" is now first and highlighted (Enter picks it).
  Builder's computer: Build a unit > "Install the LCD firmware" puts the colour screen's firmware on a new unit in one click - a
  XIAO straight from the bag, one in update mode or one given the black-and-white screen's build. Carries unit firmware cavec
  1.16.79 (TD-1, colour screen): one tap starts the shot's countdown (Settings > Shot timer) and a half-second hold is an
  LRUD; Tools > Cross section opens again and has Options > Mode (Manual / Timer); Tools > Lineplot assistant; no more freeze
  when buttons are pressed on USB with Tacheo open. cave 1.16.73, sap6 1.16.30 and SAP5 2.2.16 unchanged.
TACHEO 1.6.46: carries unit firmware cavec 1.16.75 (TD-1, colour screen: the off-drain finder); cave 1.16.73, sap6 1.16.30
  and SAP5 2.2.16 unchanged. Nothing else changes in Tacheo.
TACHEO 1.6.45: carries unit firmware cave 1.16.73 (TD-1, OLED), cavec 1.16.74 (TD-1, colour screen) and sap6 1.16.30;
  nothing else changes in Tacheo. After installing 1.16.73 / 1.16.74 on a unit, do a Normal calibration.
TACHEO 1.6.44: a cross section's .svg is drawn in points, so its outline is exactly 1 px in Illustrator (1 pt; stroke-width 1,
  nothing scales it) - still real size and to scale in Illustrator, Inkscape or printed at 100 %. The height bar stays 0.54 pt,
  Arial 7 pt. Sections saved before are drawn again the new way when Survey > Cross sections lists them. Carries unit
  firmware cave 1.16.64, cavec 1.16.70 and sap6 1.16.30.
TACHEO 1.6.43: SURVEY is a main section of the left menu, under Overview: Shots, Cross sections, Survey performance and
  Reckon (Shots and Survey performance were under Devices; Reckon keeps its own button below the line too). CROSS SECTIONS has
  a page of its own (Survey > Cross sections; it was a tab on Shots): every section saved on this computer, with or without a
  unit plugged in, its own Download new shots, and an amber dot on Survey when a download brings new ones. A section's .svg
  now has the station's name under the outline and the scale bar on the left - the height dimension bar, top to bottom of the
  section, with the height in whole feet (7') - as on a map plate (walls 1.0 pt - 1 px from 1.6.44 - the bar 0.54 pt, Arial 7 pt; groups "outline",
  "scale-bar" and "station"). Every unit's sections get it; ones saved before are drawn again the new way when the page lists them.
TACHEO 1.6.42: the TD-1 with the colour screen (the 2" colour screen and one button) has its own firmware, the cavec build,
  in firmware\ (Tacheo 1.16.59 cavec). Plugged in and running, it is offered only its own build, as every unit is. In update mode
  Tacheo asks which unit it is: pick "TD-1, colour screen" for it ("Cave unit" is the Tacheo with the black-and-white
  screen; the plain cave build would leave the colour screen dark). "Update firmware only.cmd" asks the same (6 = the TD-1
  with the colour screen). Diagnosis and Build a unit check its colour screen from the self-test.

TACHEO 1.6.40: a cross section's .svg (Shots > Cross sections > Open the SVG, or beside its .csv in Shot downloads\<unit>\
  Cross sections\) is the outline and a scale bar only, to scale at the unit's scale (1 in = 20 ft unless the unit set another),
  real size - it keeps its scale in Illustrator or Inkscape (groups "outline" and "scale-bar") or printed at 100 %. No readings,
  station or sheet in it; the Shots page still shows the section on its sheet with every reading. Sections downloaded before
  are redrawn the new way when the Shots page lists them.
TACHEO 1.6.39 (with unit firmware 1.16.57): the trip log flags a CrossTalk link that keeps dropping 30 s after it came up
  (a Bluetooth request left unanswered - the 5xc and the Cavway, 25 Oct; 1.16.57 answers an instrument's pairing request), and
  names why each link dropped (1.16.57 keeps the reason). 1.6.38: the cross-section help for 1.16.57 (Time 10 s - 2 min, up to
  400 readings, no Room); switch-off 6 = SHOT + MENU held, or the one button held 10 s; 7 = a calibration left 30 min.
UNIT FIRMWARE 1.16.57 (Tacheo 1.6.39): READY names the CrossTalk partner ("Lost:" when it drops); the
  Bluetooth menu; one-button long tap selects at 0.5 s with the tap's tick, the button held 10 s = off; the field meter ticks
  always, doesn't blink, any press leaves; cross sections keep every reading (Time up to 2 min, 30 s first); taps kept while
  pages load. See Tacheo_v1.16.57_<build>.zip.txt.
TACHEO 1.6.37: Check the Tacheo reads the unit's usage log (unit firmware 1.16.56: every button press and let-go, the
  page after it and how long it took, laser readings, shots and their steadiness, menu picks, CrossTalk, cross sections,
  tools, battery), keeps every record in "Devices\<serial>\usage log.csv" and sums it up in the report (USAGE LOG). On a
  TD-1 it also times each of the laser's measuring modes (LASER MODES, about 25 s: keep it aimed at a wall 1-5 m away). A unit
  asleep on USB is reported as asleep, not as a list of faults.
TACHEO 1.6.36: cross sections (unit firmware 1.16.47, Tools > Cross section) are downloaded with the shots into
  "Shot downloads\<serial>\Cross sections\": a .csv of the readings and a real-size .svg field-book sheet (4 5/8 x 7 in,
  at the unit's page scale, with a height bar) to print at 100 % and trace. Shots > Cross sections shows them.
TACHEO 1.6.35: a SAP5 with a XIAO and the 2" colour screen (sap5xc build) is updated like any Tacheo on a Tacheo that
  carries its build, and named in the "Which unit is waiting in update mode?" question (the plain sap5x build would leave
  its colour screen dark). Build a unit and Diagnosis check its colour screen from the self-test.
TACHEO 1.6.34: a SAP5 with a XIAO wired on (sap5x build) is updated over USB like any Tacheo, on a Tacheo that carries
  its build; a unit in update mode is asked about by name.
TACHEO 1.6.33: unit firmware 1.16.12 and SAP5 firmware 2.2.16; the storage page names the tool data "Elevation zero".
TACHEO 1.6.32: the SAP5 update is now inside Tacheo - Updates and Upgrades > SAP5 > "Update this SAP5": switch the SAP5
  off and plug it in; Tacheo reads it, says what it has and what is kept, saves a backup, installs the firmware and checks
  every byte (about a minute). Settings, calibration, health log and owner name are kept, as with the upgrader page (still
  there: "Open the upgrader page"). Test new firmware installs SAP5 test firmware the same way. Unit firmware 1.16.9.
TACHEO 1.6.31: Build a unit, under Updates, on the builder's computer only (builder.txt next to Tacheo) - the steps for
  a new cave unit on one page: install the released firmware, the serial number, the checks (screen, tilt sensor,
  compass, laser, storage chip, battery, buttons, Bluetooth), the button presses, the laser station (no tape: the
  rear rod tip in the station seat, the target at a set distance; +-3 mm passes, otherwise trim the offset), the
  calibration, and a build record per unit ("Build records\Build log.csv", Export copies it).
TACHEO 1.6.30: small fixes - the SAP6 Upgrade card says that converting replaces Phil's files on the SAP6's drive (the
  backup is their only copy); on Diagnosis, one check at a time ("Check a BRIC" no longer starts during another check).
TACHEO 1.6.29: Reckon, at the bottom of the left menu - drop a Walls survey (.srv files or a whole cave's .wpj) on
  Tacheo: it finds slips of the pen, legs shot the wrong way round, wrong declinations, a steady FS/BS split, a clino
  index error and each Tacheo calibration's own small error, boxes the problem numbers in red, lists what to do, and
  writes a corrected copy (the original is never changed). The left menu in groups that drop down; "Search help" at
  the top of the menu (or F1) answers questions about Tacheo, with Show me walkthroughs; Help and how-to under Help.
TACHEO 1.6.28: Devices > a unit > Shots shows your surveys by day (find a station such as FSB123), each with the
  calibration it was shot with; click any calibration ID for everything about it - the magnetic field and dip it saw, its
  figures, each hold, the calibration before it and how far the two differ in bearing, the surveys shot with it.
TACHEO 1.6.27: Test new firmware has no time limit (start the test, use the unit, finish and save) and takes a SAP5
  too (read while it is off and plugged in); Diagnosis > Check a BRIC.
TACHEO 1.6.26: Test new firmware (the last page in the list): try firmware that hasn't been released on your own unit -
  if you are not Sully, at your own risk. The Beta test page is now part of Diagnosis (the trip log at the bottom; Check the
  Tacheo, then Send to Sully).
TACHEO 1.6.25: nothing changes for you. On the builder's PC only: new firmware is tried on the builder's own units
  (Release test) before it is released to anyone. Unit firmware unchanged (1.16.6).
TACHEO 1.6.24: unit firmware 1.16.6 (fixes 1.16.5's start-up crash).
TACHEO 1.6.23: Survey performance > Statistics to date - the Footage card's headline is the average footage a trip (the
  total to date under it); a freeze's place in the firmware in the restart text; Settings > Screen named Right hand / Left
  hand for SAP6 and cave units. Unit firmware 1.16.5.
TACHEO 1.6.22: unit firmware 1.16.4.
TACHEO 1.6.21: Trip review is now SURVEY PERFORMANCE, opening on a STATISTICS TO DATE tab - the average of all your trips
  (one unit or All units); each trip on the TRIPS tab. On the builder's PC a new Tacheo gets its serial number by itself.
  Unit firmware 1.16.3.
TACHEO 1.6.20: unit firmware 1.16.2 (Tools > Sketch; a cleaner READY).
TACHEO 1.6.19: unit firmware 1.16.1 (the battery % also while charging).
TACHEO 1.6.18: the breadboard Tacheo is gone - a Tacheo gets the cave build (Tacheo no longer asks which board);
  the firmware folder is read again before every install (a package moved since Tacheo started no longer fails as
  "missing"); unit firmware 1.16.0.
TACHEO 1.6.17: the credit line now reads "by Phillip Sullivan (Sully)".
TACHEO 1.6.16: unit firmware 1.15.1 and its manuals.

TACHEO 1.6.15: unit firmware 1.15.0 and its manuals; Settings page > Bluetooth > Crosscheck role (Auto / Foresight /
  Backsight; firmware 1.15.0) - the partner Tacheo takes the other role.

TACHEO 1.6.14: the battery while switched off - the full report and Trips and events show each time off (how long, the
  battery before and after, whether it went fully off) and say if the battery runs down while off (firmware 1.14.2); Trip
  review ends a survey after 2 hours with no shot (was 4), as the unit now does.

TACHEO 1.6.13: every Tacheo gets only its own firmware build. The Tacheo's own cave units (v1.5 / v2) run the "cave"
  build (firmware 1.14.1 and later); the breadboard build would leave their screen and compass dark, so Tacheo never
  offers it to them. This version of Tacheo doesn't carry the cave build yet: install it from its .uf2 file until one does. A unit
  in update mode (or one that doesn't answer) can't say which it is: Tacheo asks first.

PAGES
  Overview   Serial number, owner, firmware (and the date it was built), battery and shots
             left, calibration, today's totals. Plug the Tacheo in with a USB-C DATA cable
             (on or off) and it connects by itself. Its clock is set from the computer.
             1.5.4: when a newer version of Tacheo is out, an UPDATE AVAILABLE card sits at the top: the
             new version, what's in it (each change tagged TACHEO, TACHEO, SAP6 or SAP5,
             including any newer unit firmware inside it, and a note when the plugged-in unit
             would get newer firmware from it) and a large "Install update now" button. The
             download and install progress show on the card. "Later" hides it until next start.
             1.5.7: SEVERAL UNITS AT ONCE - see below. The pages show the unit picked in the
             "Units:" row under the top bar.
             1.6.4: a STORAGE tile shows how full the unit's memory is (firmware 1.12.1); from
             95 % Tacheo offers to clear the logs. When a unit that crashed, froze or restarted
             without being turned off is plugged in, Tacheo says so and offers the beta-test report.
             1.6.5: click the STORAGE tile for the Storage window - every file on the unit and what can
             be cleared (shot log, trip log, saved calibration holds, tool data), saved on the computer
             first; Tacheo warns from 88 %. A FOOTAGE tile: the footage of the last trip and the
             average per trip.
  Devices    1.6.5: ONE PAGE FOR EVERY INSTRUMENT - Tacheo, SAP6, SAP5 and (read only, see OTHER
             INSTRUMENTS below) DistoX, Cavway and BRIC. On the left: "Read a device", what is PLUGGED
             IN NOW, and "Saved devices" - every unit seen, in a drop-down. Pick one: its name,
             firmware and calibration verdict, buttons for what that unit can do (Read it again,
             Calibrate, Set its clock, SAP5 tools, SAP6 tools, Calibration, Shots, Survey performance, Open
             its folder), then Overview, Shots, Calibrations, Trips and events and Usage. The SAP5 and
             SAP6 pages are now "SAP5 tools" and "SAP6 tools" on that unit's page.
             1.6: every Tacheo, SAP6 and SAP5 this computer has seen, with its history, built up by
             itself each time a unit connects (kept in "Devices\<serial>\"). Pick a unit on the left:
             Summary (firmware over time, first / last seen, totals), Shots (every download saved
             for it, merged), Calibrations, Trips and events (one row per power-on from the trip
             log: how long, shots, failed shots, battery, how it ended), Usage (one row per
             connection). "Full history of this unit" on the Shots and Calibration pages opens it.
             SAP5 (firmware 2.2.9+): shown on the Overview by itself when plugged in switched off;
             Tacheo stores this computer's time on it - unplug it, then switch it on to set its clock.
  Survey performance  1.6.21 (was Trip review): opens on STATISTICS TO DATE, the average of all your trips - the totals,
             the time between shots over every trip (where the time went; best, average and last trip; getting faster or
             slower), the FS/BS agreement over every pair, footage and ft/h, the average trip, personal bests (click one
             to open that trip), the next-trip estimate and trip-by-trip charts with the average as a dashed line. The
             unit picker starts with All units (every unit's trips on this PC), or pick one.
             TRIPS tab (1.6.5): how each trip went, from the shots and the trip log. The headline is the
             time between shots, then the FS/BS agreement, then the footage. Waits (the unit on, 2 min
             or more between shots - talking, waiting on someone) are counted; breaks (the unit switched
             off) are left out. A trip is a day's survey: it ends at Stations > End survey (firmware
             1.13.0) or after 2 hours with no shot (4 before 1.6.14). Footage per hour while shooting, the survey rate,
             a next-trip estimate at the objective, and the shots to look at.
  Shots      Download the shots stored on the Tacheo (its newest 200-400): saved as a
             spreadsheet (.csv) and a Survex file (.svx) in "Shot downloads\<serial>\".
             "Download new shots" only takes the ones since last time. "Clear logs" (1.6.4)
             saves new shots and the trip log first, then empties the shot log and the trip log
             (calibration and settings are kept). Station numbers are a first draft: check your book.
             1.6.5 (firmware 1.13.0): "Stations" - type the trip's designators (A, B, SC ...) and send
             them to the unit, see the station it is at and set it. With Settings > Leg track On the
             unit names every shot FROM / TO itself (Stations menu: hold MENU), and the downloads
             carry those names (the "stations" column).
             1.5.5 (firmware 1.10.4): each shot carries the ID of the calibration it was taken
             with - the "calibration" column of the .csv and a comment in the .svx.
             1.5.7: "Download from all units" (two or more connected): the new shots from each
             unit in turn, each saved in its own "Shot downloads\<serial>\" as usual, plus one
             spreadsheet for the pair, "Shot downloads\Pair <date time>.csv", with every shot of
             both units in time order and a Unit column (serial and owner) first.
             1.6.36 (firmware 1.16.47): every download also saves the unit's new cross sections (Tools >
             Cross section: aim at the next station for the 1-second count, then sweep the walls for 8 s)
             in "Shot downloads\<serial>\Cross sections\" - "<station> <date time> #<id>.csv" (every
             reading) and ".svg", the section on a real-size 4 5/8 x 7 in field-book sheet at the unit's
             page scale (1 in = 20 ft unless set; a larger one if it doesn't fit), with a height bar:
             print it at 100 %. Survey > Cross sections lists them, newest first, with the sheet (1.6.43: a page of its own;
             the .svg has the station and the height bar on the left).
  Calibration  1.6.9: "Check for metal and drift" (Diagnosis page since 1.6.11) - was there metal near the unit during a
             calibration, has the compass's own magnetism changed since (something near it magnetised or moved), and
             how far have marks shot again (a home course) moved, forward against back. The result is shown on the
             Diagnosis page to send to Sully; the full report (Check the Tacheo / Beta test) has the same check.
             1.6.10: "Find the magnet" (Diagnosis page since 1.6.11; firmware 1.13.1, USB) - for bearings that drift days after a
             calibration. SPIN TEST: turn the unit every way for 40 s, outdoors or on a wooden table away from steel:
             how far its own magnetism has moved since the calibration (µT and degrees of bearing). Each result is kept
             ("Calibration records\<serial>\find the magnet.csv"); repeat it every day or two to see whether it grows,
             settles or jumps. GUIDED PART TEST (about 3 minutes, an ordinary fridge magnet - not a neodymium one):
             the magnet touched to one spot of the case at a time, a 15 s spin after each - which part holds
             magnetism, and what to do about it. RECALIBRATE afterwards. LIVE METER: the change from a still
             baseline. "Send to Sully" puts the results on the Diagnosis page.
             1.5.7: works out what is plugged in by itself - a Tacheo, a SAP6 running
             Tacheo, a SAP6 on Phil's firmware (read from its drive) or a SAP5 / Tacheo-SAP5
             (switched OFF, then plugged in: read once each time it's plugged in, nothing on it
             changed) - names it next to "Read again" and shows that unit's calibration and
             health. For a Tacheo or SAP6 running Tacheo:
             At a glance: EXCELLENT (gold, with a star - 1.5.8) / GOOD (green) / CHECK ADVISED
             (orange) / RECALIBRATE / NOT CALIBRATED (red). EXCELLENT: a calibration under 0.15 deg,
             or - once there are 5+ flat FS/BS pairs since the calibration - their average agreement
             under 0.20 deg (the backsights win either way). Firmware 1.10.5 rates it itself; Tacheo
             works it out the same way for older firmware and for a SAP5. The calibration records
             list shows EXCELLENT for a calibration under 0.15 deg. Each part's accuracy (compass, clino, laser aim) and
             when and how it was calibrated, the calibration in use, the front/back sight
             agreement average, benchmarks, the calibration history, and a plot of the
             backsight errors against bearing (needs firmware 1.7).
             1.5.5 (firmware 1.10.4): CALIBRATION RECORDS - every change to the calibration has an
             ID, the serial number and a number (e.g. TCH-5D8413F6-C008); the list shows each one
             with when it was saved, its type, result, accuracy, fit, field, dip, temperature,
             holds and holds left out (the one in use in bold). "Save calibration records" keeps
             them in "Calibration records\<serial>\": one .txt per calibration (its figures and
             the full correction it applies), "<ID> holds.csv" (the raw holds that made it),
             calibrations.csv (one row per calibration), and "all instruments.csv" one folder up
             (every calibration of every instrument this computer has seen). Tacheo also saves
             them whenever the unit connects and when shots are downloaded; the unit itself keeps
             only its newest 8-16, so connect it after calibrating. Double-click a row to open it.
  Beta test  1.6.7: "Send the report to Sully" sends ONE FULL REPORT - the same as Diagnosis > Check the Tacheo:
             the self-test, the trip log, the calibration and every record the unit keeps, the storage, the station
             names, the trips and this computer's history of the unit, and every stored shot (the email leaves out
             the oldest shots if it is too long; the saved copy in "Beta-test reports\" has all of them).
             After each trip: "Read the trip log" shows every power-on (when, how long, shots,
             failed shots, battery start -> end, how it ended - in red if it restarted by itself
             or ran flat) and what to look at. "Send beta-test report" adds the self-test, the
             calibration and every stored shot and emails it all to Sully with your notes
             (saved in "Beta-test reports\" too). Needs Tacheo firmware 1.8 (1.9 also counts the
             shots and time of the power-on that's still running).
  Owner      The name on the start-up greeting, and the birthday (Happy Birthday that day).
  Settings   Every setting in the Tacheo's Settings menu, plus the survey tolerances.
             Firmware 1.10 adds "Screen / Autoflip": the picture turned round or not, and
             whether it turns over by itself when the unit is held the other way.
             Firmware 1.10.1 adds "Shot hold": how long to hold the shot button for a shot
             (1.5 to 5 s, 3 s by default).
             Firmware 1.10.2: units are feet by default (a unit switches to feet once when it
             first starts 1.10.2; Units here still changes it).
             Firmware 1.10.3: calibrations can no longer "collapse" (every shot reading the
             same); holds taken next to metal are named (COMPASS DISTURBED) and can be retaken
             or left out; a collapsed calibration is thrown away at start-up (CALIBRATION
             RESET); start-up screen 4 s with "by Sully", health screen 4 s.
  Updates and Upgrades (1.5.2: one tab per kind of unit; it opens on the tab for the unit
             that is plugged in, and an amber dot marks a tab with something newer to install)
             TACHEO tab: Tacheo firmware for the Tacheo (its own build: breadboard, or cave for a cave unit, 1.6.13) - the newest version
             in firmware\ with its release date and what's new, what the plugged-in Tacheo has,
             and the version history. "Update" installs it in about a minute. Settings,
             calibration, owner, serial number and stored shots are kept.
             SAP6 tab > Updates: the same for a SAP6 running Tacheo (sap6 build).
             SAP6 tab > Upgrade: "Convert this SAP6 to Tacheo" copies everything on the SAP6's
             drive to "SAP6 backups\" (each file checked), notes Phil's hardware version,
             installs Tacheo for the SAP6 (about a minute) and sets Tacheo's units, angles,
             auto-off and laser offset to match Phil's. Then calibrate it with Tacheo before
             surveying: Menu > Calibrate > Normal > All sensors, then Menu > Calibrate > Check.
             (Phil's calibration isn't carried over: his maths is what put the SAP6's compass
             6-8 deg off.) "Restore Phil's firmware" (a SAP6 running Tacheo, USB cable) clears
             the Tacheo's settings, calibration and stored shots (download the shots first) and
             puts back CircuitPython 9.0.0 for the SAP6 (what Phil's own installer uses) and his
             hardware version; his code, settings and calibration were never touched on the drive.
             A unit waiting in update mode (an install that stopped) can't say what it is: install
             from the TD tab for a Tacheo (1.6.13: Tacheo asks whether it is a cave unit or the
             breadboard Tacheo), or SAP6 > Updates for a SAP6.
             1.5.8: a green "Up to date" bar on the Tacheo / SAP6 card when the unit shown already has
             the newest firmware in the firmware\ folder.
             1.6.2: Tacheo firmware 1.11.1 (Tacheo and SAP6): new Tools - Rigging, Live tape,
             Turnaround alarm, Depth and Strike & dip - and Settings > Leg track (Off by default) for
             Depth and loop closures that point to the leg to re-shoot. See the manual's Tools pages.
             1.11.1 also fixes a unit freezing at READY when Phone link and Crosscheck detection were
             both Off, and the laser dot staying on after backing out of a tool.
             1.6.5: Tacheo firmware 1.13.0 (Tacheo and SAP6): station names and the Stations menu
             (Side lead, End survey), and the unit makes room by itself when its storage is full.
             1.5.7: an install goes only to the unit picked in the "Units:" row (the card says
             "On S/N ..."); other Tacheos can stay plugged in. A unit waiting in update mode, or a
             SAP6 on Phil's firmware, still has to be the only one plugged in. Every install writes
             a step-by-step log in "Update logs\".
             SAP5 tab: the newest Tacheo-SAP5 upgrader in sap5\ with its version, release date
             and what's new. "Open the SAP5 upgrader" opens it in Edge or Chrome, which can talk
             to the SAP5 over USB; it backs the unit up first. "SAP5 user guide" opens the guide.
             TACHEO tab: this program's version. Tacheo looks for a newer version of Tacheo a few seconds
             after it starts (switch it off there) or when you click "Check now"; it reads one
             small file from Sully's Google Drive and sends nothing else. When there is one, the
             Overview shows it (above) and a bar at the top of the other pages offers "Install
             update": Tacheo downloads it, checks it, closes, replaces
             its own files and opens again (shot downloads, backups, logs and reports are kept).
             If Windows won't let it change its folder (e.g. under Program Files), "Open the
             download page" opens the Drive folder instead.
  SAP5       (1.6.5: Devices > the SAP5 > "SAP5 tools")
             For original SAP5s and Tacheo-SAP5: switch the SAP5 OFF, plug it in, "Read
             the SAP5". Shows its health verdict in colour, each part's accuracy, roll
             check, benchmarks, the FS/BS agreement and a backsight plot, battery learning.
             Change its settings (units, style, auto-off, Autoflip (2.2.6), LRUD ref, long-leg and low-battery
             warnings, all tolerances) and the owner name: "Write settings to the SAP5"
             saves a backup in "SAP5 backups\", erases, rewrites and checks every byte
             (about a minute; its bootloader can only erase everything at once).
             "Save a backup" any time. If a write is interrupted, "Finish the unfinished
             change" puts the saved copy on. (The SAP5 stores no survey legs: only its
             last 20 shots until it is switched off, so there is nothing to download.)
  SAP6       (1.6.5: Devices > the SAP6 > "SAP6 tools")
             Phil Underwood's Shetland Attack Pony 6, on Phil's firmware or running Tacheo.
             Plug it in with a USB-C data cable and switch it on. On Phil's firmware it shows
             up as a drive called SAP6: the page shows his firmware and CircuitPython versions,
             his calibration figures (holds, field, dip, gravity), the newest error his firmware
             logged, his settings and the backups ("Save a backup" any time). Running Tacheo:
             firmware, battery, calibration verdict and accuracy, backsights, drift, today's
             totals and the main settings; "Copy Phil's settings" sets units, angles, auto-off
             and laser offset from the newest backup of Phil's drive. Converting and restoring
             are on the Updates and Upgrades page.
  Diagnosis  Finds where a fault is and emails the report to Sully.
             1.6.11: "Bearings drifting?" row - "Check for metal and drift" and "Find the magnet" (moved here
             from the Calibration page): for bearings that drift days after a good calibration.
             1.6.7: "Check the Tacheo" makes the one full report (see Beta test). "Check a DistoX" (read only, by
             Bluetooth): its firmware and board, its calibration and how its last calibration run fits it, its modes,
             unsent shots and every shot in its memory. Devices > the DistoX > "Back up its firmware" (read only):
             switch it on in its installer mode (hold PLUS and MINUS, press DIST) and Tacheo keeps a copy of its whole
             memory in "Devices\<unit>\firmware backups\".
             1.6.9: a DistoX2 or Disto XBLE running Sully's own Tacheo firmware (a test version) is recognised:
             its firmware shows as "Tacheo <version>", and the report adds what that firmware keeps - the
             calibration number and figure, the last 4-shot Check, the backsights, restarts, battery - and its
             trip log (switch-ons, calibrations, refused holds, Checks, failed shots).
             "Check the Tacheo": plug it in, switch it on, rest it pointed at a wall 1-5 m
             away. It tests the screen, tilt sensor, compass, laser, buttons, battery,
             calibration and stored shots (about 10 s; needs firmware 1.7).
             "Check a SAP6": a SAP6 running Tacheo gets the full Tacheo check; one on Phil's
             firmware is read from its drive (versions, calibration, error log, settings).
             "Check a SAP5": switch the SAP5 OFF, then plug it in (upgrade mode). Tacheo
             reads its firmware version, settings, calibration and health log.
             Read-only: nothing on any unit is changed.
             Each finding says OK / NOTE / CHECK / PROBLEM, what it means and what to do.
             Write what's going wrong (name/email and phone optional, tick "OK to text
             me" if a text is fine), then "Send to Sully" (needs the internet only then).
             Every report is also saved in "Diagnosis reports\". If it can't send, it
             offers an email to Sully with the saved report to attach.
  Suggestions  An idea for a new feature, or something that should work differently: pick
             what it's about (Tacheo, Tacheo, phone app, SAP6, SAP5, other), write it, "Send
             suggestion". It's emailed to Sully (same route as the reports; no Tacheo
             needed) and a copy is kept in "Suggestions\".
  Manuals    (1.5.7, last in the list on the left) The printable instruction manuals, one per
             kind of unit: Tacheo, SAP6 running Tacheo, SAP5 / Tacheo-SAP5 (PDF, about 35 pages,
             US Letter, with pictures of the screens). 1.6.9: the Tacheo and SAP6 manuals for firmware
             1.13.0 (station names, End survey, storage), and a manual for the DistoX2 / Disto XBLE running
             Tacheo's own firmware (a test version until it has run on a real DistoX). The one for a connected unit is marked.
             "Open the manual" opens it in your PDF viewer (print it from there), "Print" sends it
             straight to the printer when the viewer allows it, "Show in folder" shows the file
             in manuals\.

OTHER INSTRUMENTS (1.6.5) - read only
  Tacheo reads other makers' instruments as they are: their firmware is never changed. Devices >
  "Read a device", pick the kind:
  Cavway X1  USB cable, switched on. Its shots, calibration and clock. "Set its clock" puts the
             computer's time on it (asks first, then reads it back).
  BRIC4 / BRIC5  USB cable: it shows as a drive. Its shot files and calibration report are read;
             nothing is written.
  Disto XBLE (1.6.8)  CaveDevice's DistoX2 board on Bluetooth LE: no pairing in Windows - switch it on, then
             Devices > Read a device > "Find and read the XBLE". Everything below for the DistoX2 works on it the
             same way (report, Calibrate, Calibration mode off, Back up its firmware).
  DistoX / DistoX2 (X310 and A3)  Bluetooth only - it has no USB data port. Pair it once in
             Windows' Bluetooth settings (PIN 0000), then pick its port. Tacheo reads its memory and
             never marks the shots as sent, so TopoDroid or PocketTopo still get them. Its calibration
             coefficients and calibration / silent mode are shown. "Calibration mode off" switches
             it back (asks first).
             "Calibrate" - a DistoX calibration without TopoDroid: Calibration mode on, take 56 shots
             (14 directions all round, 4 at each with a quarter turn about the laser between them),
             Read the calibration shots. Tacheo works out the calibration, rates it (EXCELLENT under
             0.3 deg, GOOD under 0.5, FAIR under 0.8, else POOR) and compares it with the one the
             DistoX has. "Write it to the DistoX" only if it is better: the old calibration is saved
             first ("Devices\<unit>\calibration backups\") and can be put back.
             1.6.9: a DistoX2 or Disto XBLE running Sully's Tacheo firmware reads the same way; its firmware
             tile shows "Tacheo <version>" and its report adds the Tacheo figures and trip log.
  Shots from any of them are saved in "Shot downloads\<unit>\" (.csv and .svx), new ones added at
  each read; station numbers are a first draft. Calibration status, shots, trips and footage are on
  the unit's Devices page.

SEVERAL UNITS AT ONCE (1.5.7)
  Tacheos are used in pairs, so Tacheo connects to every one plugged in by USB, and you can
  add more by Bluetooth, in any mix. With two or more, a "Units:" row under the top bar lists
  them (serial, owner, USB or Bluetooth): click one and every page shows that unit. "Download
  from all units" on the Shots page saves the new shots of all of them in one go. Unplugging
  one (or its Bluetooth link dropping) leaves the others connected. The same unit is never
  connected twice: plugged in by USB, its Bluetooth link closes.

BLUETOOTH (NO CABLE)
  Click "Bluetooth" (top right; "Add by Bluetooth" when a unit is already connected - 1.5.7).
  The Tacheo must be switched ON (it doesn't advertise while off) with Settings > Bluetooth >
  Phone link on; the computer needs Bluetooth (Windows 10/11, Bluetooth 4.0 or newer - almost
  any). Pick it from the list (owner and serial shown). There is no pairing in Windows'
  Bluetooth settings: Tacheo connects to it directly (the Tacheo won't show in Windows' own
  Bluetooth list, and doesn't need to).
  1.5.8: FIXED - Tacheo 1.2-1.5.7 said "Bluetooth needs Windows 10 or 11" on every Windows 10
  and 11 computer (Windows reported itself as Windows 8 to it), so Bluetooth never started. It
  now checks the computer's Bluetooth itself and says plainly if it is missing or switched off.
  Everything works over Bluetooth except firmware updates (cable or the phone app for now).
  "Disconnect" ends the link of the unit shown (1.5.7: the others stay). If it won't
  connect, "Bluetooth log.txt" next to the program says why; a Diagnosis report includes
  it.

Needs Tacheo firmware 1.1 or newer for Overview, Owner and Settings, 1.6 or newer for
Shots, and 1.7 or newer for the full Diagnosis self-test. An older Tacheo can still be
updated (Updates and Upgrades > Tacheo), which brings everything else.
Close the Arduino Serial Monitor (or anything else using the Tacheo) first.

IF THE .EXE CAN'T RUN (locked-down computer)
  "Update firmware only.cmd"            just the firmware update (PowerShell). It never
                                        touches a SAP6 still on Phil's firmware: convert
                                        those with Tacheo Topside.exe (Updates and Upgrades >
                                        SAP6 > Upgrade)

UPDATE OVER BLUETOOTH (no computer)
  Android: the Tacheo app, TD tab, Update.
  iPhone, or Android without the app: Nordic's free "nRF Device Firmware Update" app.
  Copy the right .zip from firmware\ to the phone (_breadboard for the breadboard Tacheo, _cave for a
  cave unit, _sap6 for a converted SAP6 - only ever the build the unit already has); on the Tacheo choose Menu > Info >
  Bluetooth update; in the app pick the .zip and the "Tacheo-XXXX" unit and press Upload.

WHAT'S IN THIS FOLDER
  Tacheo Topside.exe        the program
  firmware\                 Tacheo firmware .zip files; "<name>.zip.txt" next to each
                            holds its release date and notes
  manuals\                  the printable instruction manuals (PDF): Tacheo, SAP6, SAP5 and DistoX (1.5.6;
                            the Manuals page opens them, 1.5.7)
  sap5\                     the Tacheo-SAP5 upgrader page, its guide and release notes
  sap6\                     Phil's firmware for the SAP6, to put it back (see sap6\README.txt)
  SAP6 backups\             copies of each SAP6's drive, made before converting it
  Shot downloads\           made when you first download shots
  Devices\                  every instrument this computer has seen: its history, each read and
                            (DistoX) the calibration backups
  Diagnosis reports\        made when you first run a diagnosis
  Beta-test reports\        copies of the beta-test reports sent
  topside.ini               Tacheo's own settings (whether it checks for updates at start)
  Update logs\              a step-by-step log of each firmware or Tacheo install (the newest 40); if an
                            install fails, the message names the log to send to Sully
  contact.txt               your name and phone for the reports (remembered)
  SAP5 backups\             SAP5 backups Tacheo saves (before every settings change)
  Bluetooth log.txt         what the Bluetooth connection did (for Sully when it fails)
  support.txt               where "Send to Sully" sends reports (keep it with the program)
  tools\                    adafruit-nrfutil.exe (installs firmware), updater.ps1 (used by
                            "Update firmware only.cmd")
